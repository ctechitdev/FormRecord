<nav class="menu">
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 100%;
  background-color: #f1f1f1;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
  text-align:center;
}

/* Change the link color on hover */
li a:hover {
  background-color: #555;
  color: white;
}
h2 {
  text-align:center;
  color:darkblue;
}
h3 {
  text-align:center;
  color:blue;
}

</style>
    <div>
     <center>     
     <img src="KPLOGO.png" alt="Hot Air Balloons" width="70" height="70">
     </center>    
    </div>  
<h2>KP COMPANY LIMITED</h2>
<h3>PJP Record Admin Menu</h3>
  <ul>
    <li><a href="pjp_ExportData.php">Export file</a></li> <br>
    <li><a href="pjp_maintain.php">Mantain customer data</a></li> <br>
    <li><a href="pjp_ViewCust.php">View customer</a></li> <br>
    <li><a href="pjp_ViewData.php">View pjp Record</a></li>
	
 
  </ul>
</nav>