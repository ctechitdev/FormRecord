 
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.slimscroll.js"></script> 
    <script src="js/waves.js"></script> 
    <script src="js/sidebarmenu.js"></script> 
    <script src="js/sticky-kit.min.js"></script> 
    <script src="js/custom.js"></script> 
    <script src="js/tablesaw.js"></script>
    <script src="js/tablesaw-init.js"></script> 
 
	
	
    <script src="js/dashboard1.js"></script>  
    <script src="js/footable.all.min.js"></script>   
    <script src="js/footable-init.js"></script> 
    <!--Custom JavaScript -->
    <script src="js/validation.js"></script> 
 
	<script>
    ! function(window, document, $) {
        "use strict";
        $("input,select,textarea").not("[type=submit]").jqBootstrapValidation(), $(".skin-square input").iCheck({
            checkboxClass: "icheckbox_square-green",
            radioClass: "iradio_square-green"
        }), $(".touchspin").TouchSpin(), $(".switchBootstrap").bootstrapSwitch();
    }(window, document, jQuery);
    </script> 
    <script src="js/jquery-clockpicker.min.js"></script>
   <!-- Date Picker Plugin JavaScript -->
    <script src="js/bootstrap-datepicker.min.js"></script>
	
	 <script src='js/jquery.dateFormat.js'></script>
<script  src="js/date_picker.js"></script>


 <script type="text/javascript">
$('.clockpicker').clockpicker()
	.find('input').change(function(){
		console.log(this.value);
	});
var input = $('#single-input').clockpicker({
	placement: 'bottom',
	align: 'left',
	autoclose: true,
	'default': 'now'
});

 
 
</script>	

 
    <!-- ==========